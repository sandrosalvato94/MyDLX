
design_vision -f ./CSA_CLA/CSA_CLA.scr 

design_vision -f ./CSA_RCACSA_RCA.scr 

design_vision -f ./P4/P4.scr 

design_vision -f ./PCLA/PCLA.scr 

design_vision -f ./RCA/RCA.scr 

